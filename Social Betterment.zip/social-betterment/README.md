# Social Betterment
We intercept your social media posts to tell you if your writing is toxic. [Chrome Extension]

This was vibe coded in 2 days. You have the confidence to take it and modify it too.

## Users

Download the file named 'Social Betterment.zip'.

Unzip the Chrome Extension into a folder and follow these [instructions](https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/#load-unpacked)

## Developers

To experiment with this prototype, please clone this repo and use 'Load Unpacked Extension'.
Read more on [Development Basics](https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/#load-unpacked).


Supply your own free PERSPECTIVE_API_KEY from [https://www.perspectiveapi.com/](https://developers.perspectiveapi.com/s/docs-get-started)


## Contributing

Please fork your own copy, I will follow your lead.

## License

This is licensed under the [MIT License](/LICENSE).