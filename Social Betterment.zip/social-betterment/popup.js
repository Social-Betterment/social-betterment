// popup.js

document.addEventListener('DOMContentLoaded', function() {
  // You can add any popup-specific logic here if needed
});
